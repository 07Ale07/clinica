<?php
require_once '../conexion.php';

class OdontologoModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function obtenerOdontologos() {
        $query = "SELECT p.id_persona, p.nombre, p.apellido, pr.matricula 
                  FROM personas p
                  JOIN empleados e ON p.id_persona = e.id_persona
                  JOIN profesionales pr ON e.id_empleado = pr.id_empleado
                  JOIN cargo_empleados ce ON e.id_empleado = ce.id_empleado
                  WHERE ce.id_cargo = 1"; // Asumiendo que 1 es el id_cargo para odontólogos
                  
        $result = $this->db->query($query);
        $odontologos = [];
        
        while ($row = $result->fetch_assoc()) {
            $odontologos[] = $row;
        }
        
        return $odontologos;
    }
}
?>