"use client"

import AppNavigator from "../src/navigation/AppNavigator"

export default function SyntheticV0PageForDeployment() {
  return <AppNavigator />
}