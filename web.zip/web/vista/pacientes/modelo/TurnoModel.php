<?php
require_once __DIR__ . '/../conexion.php';

class TurnoModel {
    private $db;

    public function __construct() {
        $database = new Database();
        $this->db = $database->getConnection();
    }

    public function crearTurno($id_persona, $id_empleado, $fecha, $hora) {
        $fecha_inicio = $fecha . ' ' . $hora . ':00';
        
        // Calcular fecha_fin (asumiendo 1 hora de duración)
        $fecha_fin = date('Y-m-d H:i:s', strtotime($fecha_inicio . ' +1 hour'));
        
        $stmt = $this->db->prepare("INSERT INTO citas (id_persona, id_empleado, fecha_inicio, fecha_fin, estado, tipo) 
                                  VALUES (?, ?, ?, ?, 'pendiente', 'consulta')");
        $stmt->bind_param("iiss", $id_persona, $id_empleado, $fecha_inicio, $fecha_fin);
        
        return $stmt->execute();
    }
}
?>