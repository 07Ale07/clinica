<?php
 
require_once '../conexion.php'; // Asumiendo que esto define $enlace como la conexión (mysqli o PDO, aquí uso mysqli)

// Consulta para obtener todos los mensajes, ordenados por fecha descendente
$sql = "SELECT id, nombre, email, telefono, asunto, mensaje, fecha_envio FROM mensajes_contacto ORDER BY fecha_envio DESC";
$result = $enlace->query($sql);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver Mensajes - DentalSmile</title>
    <link rel="stylesheet" href="../public/css/styles_contacto.css?v=<?php echo time(); ?>"> <!-- Reusa estilos de contacto para consistencia -->
    <link href="https://fonts.googleapis.com/css2?family=Segoe+UI:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Estilos adicionales para la tabla de mensajes */
        .messages-table {
            width: 100%;
            border-collapse: collapse;
            margin: 2rem 0;
            box-shadow: var(--shadow);
        }
        .messages-table th, .messages-table td {
            padding: 1rem;
            border: 1px solid var(--gray-200);
            text-align: left;
        }
        .messages-table th {
            background: var(--gradient);
            color: var(--white);
        }
        .messages-table tr:nth-child(even) {
            background: var(--gray-100);
        }
        .messages-table .mensaje-col {
            max-width: 300px;
            word-wrap: break-word;
        }
        @media (max-width: 768px) {
            .messages-table {
                font-size: 0.9rem;
            }
        }
    </style>
</head>
<body>
   
    <section class="page-banner">
        <div class="container">
            <h2>Mensajes Recibidos Desde La Página</h2>
            <p>Aquí puedes ver todos los mensajes enviados desde el formulario de contacto.</p>
        </div>
    </section>

    <section class="contact">
        <div class="container">
            <?php if ($result->num_rows > 0): ?>
                <table class="messages-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th>Teléfono</th>
                            <th>Asunto</th>
                            <th>Mensaje</th>
                            <th>Fecha de Envío</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['id']); ?></td>
                                <td><?php echo htmlspecialchars($row['nombre']); ?></td>
                                <td><?php echo htmlspecialchars($row['email']); ?></td>
                                <td><?php echo htmlspecialchars($row['telefono'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($row['asunto']); ?></td>
                                <td class="mensaje-col"><?php echo nl2br(htmlspecialchars($row['mensaje'])); ?></td>
                                <td><?php echo htmlspecialchars($row['fecha_envio']); ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay mensajes recibidos aún.</p>
            <?php endif; ?>
        </div>
    </section>

   

    <script src="../public/js/main.js"></script>
    <!-- Agrega el script de animaciones si lo necesitas, como en contacto.php -->
</body>
</html>
<?php
$enlace->close();
?>